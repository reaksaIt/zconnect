$(document).ready(function() {
    $(window).on("load", function() {
        $('.loader').fadeOut(1000);
        $(function() {
            $('.img').Lazy({
                placeholder: "data:image/gif;base64,R0lGODlhEALAPQAPzl5uLr9Nrl8e7...",
                scrollDirection: 'vertical',
                effect: 'fadeIn',
                visibleOnly: true,
                onError: function(element) {
                    console.log('error loading ' + element.data('src'));
                }
            });
        });

        $('.slide').owlCarousel({
            nav: false,
            loop: true,
            responsiveClass: true,
            autoplay: true,
            autoplayTimeout: 10000,
            lazyLoad: true,
            items: 1,
            smartSpeed: 1000,

            // responsive: {
            //     0: {
            //         items: 1,
            //         nav: true
            //     },
            //     600: {
            //         items: 1,
            //         nav: false
            //     },
            //     1000: {
            //         items: 1,
            //         nav: true,
            //         loop: false
            //     }
            // }
        });
    });
});